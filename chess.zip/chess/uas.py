import pygame
import chess
import random
import math

# Initialize the chessboard
board = chess.Board()

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 480, 480
SQ_SIZE = HEIGHT // 8

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Fonts
pygame.font.init()
font = pygame.font.SysFont('Arial', 24)

# Q-learning parameters
LEARNING_RATE = 0.1
DISCOUNT_FACTOR = 0.9
Q_VALUES = {}
# Load and resize images (replace with your own paths)
def load_and_resize_image(path):
    img = pygame.image.load(path)
    return pygame.transform.scale(img, (SQ_SIZE, SQ_SIZE))

pawn_white_img = load_and_resize_image('assets/images/white pawn.png')
rook_white_img = load_and_resize_image('assets/images/white rook.png')
knight_white_img = load_and_resize_image('assets/images/white knight.png')
bishop_white_img = load_and_resize_image('assets/images/white bishop.png')
queen_white_img = load_and_resize_image('assets/images/white queen.png')
king_white_img = load_and_resize_image('assets/images/white king.png')

pawn_black_img = load_and_resize_image('assets/images/black pawn.png')
rook_black_img = load_and_resize_image('assets/images/black rook.png')
knight_black_img = load_and_resize_image('assets/images/black knight.png')
bishop_black_img = load_and_resize_image('assets/images/black bishop.png')
queen_black_img = load_and_resize_image('assets/images/black queen.png')
king_black_img = load_and_resize_image('assets/images/black king.png')

# Function to draw the chessboard
def draw_board(screen):
    colors = [WHITE, BLACK]
    for r in range(8):
        for c in range(8):
            color = colors[(r + c) % 2]
            pygame.draw.rect(screen, color, pygame.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))

# Function to draw pieces
def draw_pieces(screen, board):
    piece_images = {
        chess.PAWN: {chess.WHITE: pawn_white_img, chess.BLACK: pawn_black_img},
        chess.ROOK: {chess.WHITE: rook_white_img, chess.BLACK: rook_black_img},
        chess.KNIGHT: {chess.WHITE: knight_white_img, chess.BLACK: knight_black_img},
        chess.BISHOP: {chess.WHITE: bishop_white_img, chess.BLACK: bishop_black_img},
        chess.QUEEN: {chess.WHITE: queen_white_img, chess.BLACK: queen_black_img},
        chess.KING: {chess.WHITE: king_white_img, chess.BLACK: king_black_img},
    }

    for square in chess.SQUARES:
        piece = board.piece_at(square)
        if piece is not None:
            piece_img = piece_images.get(piece.piece_type).get(piece.color)
            screen.blit(piece_img, pygame.Rect(chess.square_file(square) * SQ_SIZE, (7 - chess.square_rank(square)) * SQ_SIZE, SQ_SIZE, SQ_SIZE))

# Function to get player's move input based on mouse click
def get_player_move():
    from_square = None
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                file = x // SQ_SIZE
                rank = 7 - (y // SQ_SIZE)  # Convert to chess rank (0-7 from bottom to top)
                clicked_square = chess.square(file, rank)
                if from_square is None:
                    # Select piece
                    if board.piece_at(clicked_square):
                        from_square = clicked_square
                else:
                    # Make move
                    move = chess.Move(from_square, clicked_square)
                    if move in board.legal_moves:
                        return move
                    else:
                        from_square = None  # Invalid move, reset

# Monte Carlo Tree Search (MCTS) Node class
class MCTSNode:
    def __init__(self, board, parent=None, move=None):
        self.board = board
        self.parent = parent
        self.move = move
        self.children = []
        self.visits = 0
        self.wins = 0

    def is_fully_expanded(self):
        return len(self.children) == len(list(self.board.legal_moves))

    def best_child(self, c_param=1.4):
        choices_weights = [
            (child.wins / child.visits) + c_param * math.sqrt((2 * math.log(self.visits) / child.visits))
            for child in self.children
        ]
        return self.children[choices_weights.index(max(choices_weights))]

    def rollout_policy(self, board):
        return random.choice(list(board.legal_moves))

# MCTS implementation
def mcts(board, itermax):
    root = MCTSNode(board)
    for _ in range(itermax):
        node = root
        # Selection
        while node.is_fully_expanded() and node.children:
            node = node.best_child()
        # Expansion
        if not node.is_fully_expanded():
            move = random.choice(list(node.board.legal_moves))
            new_board = node.board.copy()
            new_board.push(move)
            child_node = MCTSNode(new_board, parent=node, move=move)
            node.children.append(child_node)
            node = child_node
        # Simulation
        rollout_board = node.board.copy()
        while not rollout_board.is_game_over():
            rollout_move = node.rollout_policy(rollout_board)
            rollout_board.push(rollout_move)
        # Backpropagation
        result = rollout_board.result()
        while node is not None:
            node.visits += 1
            if (result == '1-0' and node.board.turn == chess.WHITE) or (result == '0-1' and node.board.turn == chess.BLACK):
                node.wins += 1
            node = node.parent
    return root.best_child(0).move

# Function for AI to make a move using MCTS
# Function for AI to make a move using MCTS with Q-values
def make_ai_move(board):
    root = MCTSNode(board)
    for _ in range(1000):  # Adjust the number of iterations for MCTS as needed
        node = root
        while node.is_fully_expanded() and node.children:
            node = node.best_child()
        if not node.is_fully_expanded():
            move = random.choice(list(node.board.legal_moves))
            new_board = node.board.copy()
            new_board.push(move)
            child_node = MCTSNode(new_board, parent=node, move=move)
            node.children.append(child_node)
            node = child_node
        rollout_board = node.board.copy()
        while not rollout_board.is_game_over():
            rollout_move = node.rollout_policy(rollout_board)
            rollout_board.push(rollout_move)
        result = rollout_board.result()
        while node is not None:
            node.visits += 1
            if (result == '1-0' and node.board.turn == chess.WHITE) or (result == '0-1' and node.board.turn == chess.BLACK):
                node.wins += 1
            node = node.parent

    # Combine MCTS and Q-values to select move
    best_move = None
    best_score = -float('inf')
    for child in root.children:
        move = child.move
        if move in Q_VALUES:
            score = Q_VALUES[move] + (child.wins / child.visits)  # Adjust weighting as needed
        else:
            score = child.wins / child.visits  # Fallback to MCTS statistics
        if score > best_score:
            best_score = score
            best_move = move

    if best_move is None:
        best_move = root.best_child(0).move  # Fallback to MCTS if no Q-value found

    return best_move

# Function to update Q-values after a game
def update_q_values(moves_history, winner):
    reward = 1 if winner == chess.WHITE else -1  # Reward for winning or losing
    for move in moves_history:
        if move not in Q_VALUES:
            Q_VALUES[move] = 0.5  # Initialize Q-value if not seen before
        Q_VALUES[move] += LEARNING_RATE * (reward - Q_VALUES[move])

# Function to draw turn indication
# (Drawing functions remain the same)
# Function to draw turn indication
def draw_turn(screen, turn_text):
    text_surface = font.render(turn_text, True, BLACK)
    screen.blit(text_surface, (10, HEIGHT))  # Adjust the position as needed


# Main game loop
def play_game(screen):
    screen.fill(WHITE)
    draw_board(screen)
    draw_pieces(screen, board)
    pygame.display.flip()

    moves_history = []

    while not board.is_game_over():
        # Player's turn
        screen.fill(WHITE)
        draw_board(screen)
        draw_pieces(screen, board)
        draw_turn(screen, "Your turn")
        pygame.display.flip()

        player_move = get_player_move()
        board.push(player_move)
        draw_board(screen)
        draw_pieces(screen, board)
        pygame.display.flip()

        moves_history.append(player_move)

        # Check if player wins
        if board.is_checkmate():
            print("Checkmate! You win!")
            update_q_values(moves_history, chess.WHITE)
            break

        # AI's turn
        screen.fill(WHITE)
        draw_board(screen)
        draw_pieces(screen, board)
        draw_turn(screen, "AI's turn")
        pygame.display.flip()

        ai_move = make_ai_move(board)
        board.push(ai_move)
        draw_board(screen)
        draw_pieces(screen, board)
        pygame.display.flip()

        moves_history.append(ai_move)

        # Check if AI wins
        if board.is_checkmate():
            print("Checkmate! AI wins!")
            update_q_values(moves_history, chess.BLACK)
            break

    pygame.quit()


# Initialize screen
screen = pygame.display.set_mode((WIDTH, HEIGHT + 40))  # Add extra space for text
pygame.display.set_caption('Python Chess vs AI')

if __name__ == "__main__":
    play_game(screen)
